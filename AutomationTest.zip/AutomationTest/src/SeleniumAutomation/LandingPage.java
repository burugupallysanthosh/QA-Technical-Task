package SeleniumAutomation;

import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import PageObjects.ContactUsPage;

 
public class LandingPage {
	
	
 WebDriver driver;
 ContactUsPage cuPage;
 WebDriverWait wait;
 
 
 @BeforeTest
 public void Start() {
	 
	 driver=new ChromeDriver();
	 driver.manage().window().maximize();
	 driver.get("https://www.quickseries.com/");
	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\Ajay\\eclipse-workspace\\AutomationTest\\chromedriver.exe");
	 cuPage = new ContactUsPage(driver);
	 driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	 
 }
 
  
 
@Test

public  void TestCaseOne(){
	
  		 //Navigating to Quickseries ContactUs Page 
	
        WebElement contactUsElem = driver.findElement(By.xpath("/html/body/header/div[1]/div/div/div[4]/ul[1]/li[3]"));
        contactUsElem.click();
       
        // Validating the title of the title of the Given Page 
        String ActualTitle = driver.getTitle();
        String ExpectedTitle = "Get in touch! - QuickSeries";
        assertEquals(ActualTitle, ExpectedTitle);
        
        //Validating the URL of the given Page 
        String URL = driver.getCurrentUrl();
        assertEquals(URL, "https://www.quickseries.com/contact-us/");
       
       //Visibility of FirstName TextBox
        try {
        
        WebElement firstNameTextBox = driver.findElement(By.id("inputFirstName"));
        if(firstNameTextBox.isDisplayed())
        {
        	System.out.println("The text box is present");
        }
        else
        	System.out.println("The element is not present");
       
        	}
        catch(Exception e) {
		
			}
	}
       

  
   @Test
   
   //Verifying the validation errors are shown when submitting an empty form
    public void TestCaseTwo() {
    	

    	cuPage.SetFirstName("");
    	cuPage.SetLastName("");
    	cuPage.SetOrganizationName("");
    	cuPage.SetPhoneNumber(" ");
    	cuPage.SetEmail(" ");
    
    	WebElement elemSend = driver.findElement(By.cssSelector("#wpcf7-f344-o1 > form > div.form-horizontal > input"));
    	elemSend.click();
    	
    	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    
       
    	//Validating error mesg fields are displayed
        List <WebElement> inputErrFields= driver.findElements(By.xpath("//span[@class='wpcf7-not-valid-tip']"));
        assertEquals(inputErrFields.size(),6);
    	assertEquals(cuPage.ValidateAllMandatoryFieldsForError(), false);
    	
    	//Validating the error text is "The Field is required"
    	assertEquals(inputErrFields.get(0).getText(),"The field is required.");
    	
    	//Validating the error text is " One or more fields have an error. Please check and try again."
        assertEquals(driver.findElement(By.xpath("//div[@class='wpcf7-response-output wpcf7-display-none wpcf7-validation-errors']")).getText(),"One or more fields have an error. Please check and try again.");
        
    }
  
   @AfterTest
   public void Close() {
	   
	 
	   driver.close();
	   driver.quit();
	   
   }
   
}
