package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ContactUsPage {
	
	public WebDriver driver;
	public WebDriverWait wait;
	
	
	@FindBy(name="first-name")
	public WebElement FirstNameElem;
	
	@FindBy(name="last-name")
	WebElement LastNameElem;
	
	@FindBy(name="your-company")
	WebElement OrganizationElem;
	
	@FindBy(name="phone-number")
	WebElement PhoneNumberElem;
	
	@FindBy(name="your-email")
	WebElement EmailIdElem;
	

	public void SetFirstName(String firstName)
	{
		FirstNameElem.sendKeys(firstName);
	}
	
	public void SetLastName(String lastName)
	{
		LastNameElem.sendKeys(lastName);
	}
	
	public void SetOrganizationName(String orgName)
	{
		OrganizationElem.sendKeys(orgName);
	}
	
	public void SetPhoneNumber(String phnNumber)
	{
		PhoneNumberElem.sendKeys(phnNumber);
	}
	
	public void SetEmail(String emailID)
	{
		EmailIdElem.sendKeys(emailID);
	}
	
	
	
	public ContactUsPage(WebDriver driver)
	 {
		 this.driver = driver;
		 PageFactory.initElements(driver, this);
	 }
	
	public boolean ValidateAllMandatoryFieldsForError() 
	{
		boolean result = true;
		if(!VerifyIfErrorDisplayed("/html/body/div[3]/section/div/div/div/div/div[2]/div/form/div[3]/div[1]/span/span")) 
		{
			result = false;
			return result;
		}
		if(!VerifyIfErrorDisplayed("/html/body/div[3]/section/div/div/div/div/div[2]/div/form/div[3]/div[2]/span/span"))
		{
			result = false;
			return result;
		}
		
		if(!VerifyIfErrorDisplayed("/html/body/div[3]/section/div/div/div/div/div[2]/div/form/div[3]/div[5]/span/span"))
		{
			result = false;
			return result;
		}
		
		if(!VerifyIfErrorDisplayed("/html/body/div[3]/section/div/div/div/div/div[2]/div/form/div[3]/div[6]/span/span"))
		{
			result = false;
			return result;
		}
		
		if(!VerifyIfErrorDisplayed("/html/body/div[3]/section/div/div/div/div/div[2]/div/form/div[3]/div[7]/span/span"))
		{
			result = false;
			return result;
		}
		
		if(!VerifyIfErrorDisplayed("/html/body/div[3]/section/div/div/div/div/div[2]/div/form/div[3]/span[1]/span"))
		{
			result = false;
			return result;
		}
		
	return result;
	}

	public boolean VerifyIfErrorDisplayed(String errorPath)
	{
		WebElement errorElem;
		try {
		errorElem = driver.findElement(By.xpath(errorPath));
		}catch(Exception e) {
			errorElem = null;
		}
		System.out.println(errorElem);
		if(errorElem== null) {
			return true;
		}
		else
		return false;
	}

	
}
